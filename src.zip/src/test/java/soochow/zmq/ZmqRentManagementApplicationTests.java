package soochow.zmq;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZmqRentManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
